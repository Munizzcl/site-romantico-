
document.addEventListener("DOMContentLoaded", function () {
    const startDate = new Date("2024-08-15T00:00:00");
    const counter = document.getElementById("counter");

    function updateCounter() {
        const now = new Date();
        const diff = Math.floor((now - startDate) / 1000); // segundos
        counter.textContent = `${diff} segundos`;
    }

    // Atualizar o contador a cada segundo
    setInterval(updateCounter, 1000);
    updateCounter();

    // Criar corações animados
    setInterval(() => {
        const heart = document.createElement("div");
        heart.className = "heart";
        heart.style.left = Math.random() * 100 + "vw";
        heart.style.animationDuration = Math.random() * 3 + 2 + "s";
        heart.style.top = "-10px";
        document.body.appendChild(heart);
        setTimeout(() => heart.remove(), 5000);
    }, 300);
});
